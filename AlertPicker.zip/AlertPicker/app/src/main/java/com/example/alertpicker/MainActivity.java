package com.example.alertpicker;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn;
    DatePicker dp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=(Button)findViewById(R.id.button);
        dp=(DatePicker)findViewById(R.id.datePicker);
    }

    public void open(View view)
    {
        AlertDialog.Builder a = new AlertDialog.Builder(MainActivity.this);
        a.setTitle("B. K. Birla College");
        a.setMessage("Android Tutorial");
        a.setIcon(R.mipmap.ic_launcher);
        a.setPositiveButton("ok",null);
        a.show();
    }

    public void dispdate(View v)
    {
        Toast.makeText(getBaseContext(),"Date selected:" +(dp.getMonth() +1)+
                "/" + dp.getDayOfMonth()+
                "/" + dp.getYear(),Toast.LENGTH_SHORT).show();
    }
}
