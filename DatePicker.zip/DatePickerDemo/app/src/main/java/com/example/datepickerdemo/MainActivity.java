package com.example.datepickerdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn1, btn2;
    DatePicker dp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        dp = (DatePicker) findViewById(R.id.picker);
    }

    public void open(View view)
    {
        AlertDialog.Builder obj = new AlertDialog.Builder(MainActivity.this);
        obj.setTitle("xyz College");
        obj.setMessage("Android");
        obj.setIcon(R.mipmap.ic_launcher);
        obj.setPositiveButton("OK", null);
        obj.show();
    }

    public void showToast(View view)
    {
        Toast.makeText(getBaseContext(), "Data selected : "+(dp.getMonth()+1)+" / "+dp.getDayOfMonth()+" / "+dp.getYear(),Toast.LENGTH_SHORT).show();
    }


}