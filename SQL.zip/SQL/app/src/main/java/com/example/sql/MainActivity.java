package com.example.sql;


import android.database.Cursor;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity
{
    MyHelper mh;
    EditText editName,editSurname, editMarks,editTextId;
    Button btn;
    Button btnViewAll;
    Button btnviewUpdate;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mh = new MyHelper(this); // It is going to call the Constructor of this class.

        editName = (EditText) findViewById(R.id.editText);
        editSurname = (EditText) findViewById(R.id.editText2);
        editMarks = (EditText) findViewById(R.id.editText3);
        editTextId = (EditText)  findViewById(R.id.editTextId);
        btn = (Button) findViewById(R.id.button);
        btnViewAll = (Button) findViewById(R.id.button2);
        btnviewUpdate = (Button) findViewById(R.id.button_update);
        addData();
        viewAll();
        updateData();

    }

    public void updateData()
    {

        btnviewUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                boolean isUpdate = mh.updateData(editTextId.getText().toString(),editName.getText().toString(),editSurname.getText().toString(),editMarks.getText().toString());
                if(isUpdate== true)
                    Toast.makeText(MainActivity.this,"Data Updated",Toast.LENGTH_LONG).show();

                else
                    Toast.makeText(MainActivity.this, " Data Not Updated " ,Toast.LENGTH_LONG).show();
            }
        });
    }

    public void addData()
    {
        btn.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view) {
                boolean isInserted = mh.insertData(editName.getText().toString() ,
                        editSurname.getText().toString(),
                        editMarks.getText().toString());
                if(isInserted == true)
                    Toast.makeText(MainActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();

                else
                    Toast.makeText(MainActivity.this, " Data Not Inserted " ,Toast.LENGTH_LONG).show();
            }
        });

    }

    public void viewAll()
    {
        btnViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = mh.getAllData();
                if(res.getCount() == 0)
                {
                    // show msg
                    showMessage("Error","Nothing Found");
                    return;
                }

                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext())
                {
                    buffer.append("Id : " + res.getString(0) + "\n");
                    buffer.append("Name : " + res.getString(1) + "\n");
                    buffer.append("SurName : " + res.getString(2) + "\n");
                    buffer.append("Marks : " + res.getString(3) + "\n");
                }

                // show all data
                showMessage("Data", buffer.toString());
            }
        });

    }

    public void showMessage(String title , String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}

