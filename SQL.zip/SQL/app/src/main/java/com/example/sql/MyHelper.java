package com.example.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class MyHelper extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME= "Student.db"; // DB Name
    public static final String TABLE_NAME = "student_table"; // Table Name
    public static final String COL_1 = "ID";  // Column 1.
    public static final String COl_2 = "Name"; // Column 2.
    public static final String COL_3 = "SurName"; // Column 3.
    public static final String COL_4 = "Marks"; // Column 4.


    public MyHelper(Context context)
    {
        super(context,DATABASE_NAME, null, 1);
        // SQLiteDatabase db = this.getWritableDatabase(); // it will create DB & Table.
    } // So whenever the Constructor will be called , the  Database will be created.

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("Create Table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT , NAME TEXT, SURNAME TEXT, MARKS INTEGER) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
    {

    }
    public boolean insertData(String name, String surname, String marks)
    {
        SQLiteDatabase db = this.getWritableDatabase(); // it will create DB & Table.
        ContentValues contentValues = new ContentValues(); // It is used to put the values in the Column.
        contentValues.put(COl_2,name);
        contentValues.put(COL_3,surname);
        contentValues.put(COL_4,marks);
        long result = db.insert(TABLE_NAME,null,contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE_NAME,null);
        return res;
    }

    public boolean updateData(String id,String name, String surname, String marks)
    {
        SQLiteDatabase db = this.getWritableDatabase(); // it will create DB & Table.
        ContentValues contentValues = new ContentValues(); // It is used to put the values in the Column.
        contentValues.put(COl_2,name);
        contentValues.put(COL_3,surname);
        contentValues.put(COL_4,marks);
        db.update(TABLE_NAME,contentValues,"ID = ?", new String[] {id});
        return  true;
    }

}
